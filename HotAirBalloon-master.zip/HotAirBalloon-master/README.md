# HotAirBalloon

![](https://raw.githubusercontent.com/solo5star/HotAirBalloon/master/assets/image/HotAirBalloon.gif)

<br>

# What is this?
An example plugin of vehicle.<br>
Need more description? Gif says it all!<br>

<br>

# How to use?
Type command `/vehicle create` and just ride!<br>
On windows 10, *right click*<br>
On mobile phone, *long press*<br>

<br>

# Key manual
**`↑`** Go straight and rise to the air<br>
**`→`** Turns vehicle yaw right<br>
**`←`** Turns vehicle yaw left<br>
**`↓`** Go straight and descend in the air<br>
